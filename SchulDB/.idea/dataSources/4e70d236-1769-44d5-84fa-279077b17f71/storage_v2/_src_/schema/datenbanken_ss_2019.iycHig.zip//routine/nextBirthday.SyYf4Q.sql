create
    definer = root@localhost function nextBirthday(p_birthday date, p_date date) returns date
begin
    declare nextBirthday date;
    #set nextBirthday = STR_TO_DATE(concat(day(p_birthday),',',month(p_birthday),',',year(p_birthday)));
    set nextBirthday = cast((SELECT Gebdatum FROM schule.lehrer ORDER BY DATEDIFF(Gebdatum,NOW()) LIMIT 1) as  date);
    return nextBirthday;
end;

