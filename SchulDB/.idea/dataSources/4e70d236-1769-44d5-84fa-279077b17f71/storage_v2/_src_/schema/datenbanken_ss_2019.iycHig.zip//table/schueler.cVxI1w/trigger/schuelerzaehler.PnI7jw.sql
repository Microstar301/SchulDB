create trigger schuelerZaehler
  after INSERT
  on schueler
  for each row
  BEGIN
		SET @anz=(SELECT count(*) FROM schueler WHERE knr=NEW.knr);
		UPDATE klasse SET AnzahlSchueler=@anz WHERE knr=NEW.knr;
	END;

