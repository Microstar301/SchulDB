create procedure neueAnzahlSchueler(IN knr int)
  BEGIN
    declare anz int;
    set anz = (select count(*) from schule.schueler s where s.KNr = knr);
    update klasse k set schule.klasse.AnzahlSchueler = anz where k.knr = knr;
end;

