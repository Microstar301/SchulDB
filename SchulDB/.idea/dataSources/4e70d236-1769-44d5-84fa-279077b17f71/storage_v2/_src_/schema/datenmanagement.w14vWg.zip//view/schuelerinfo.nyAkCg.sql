create view schuelerinfo as
  select `s`.`SNr`           AS `snr`,
         `s`.`Nachname`      AS `nachname`,
         `s`.`Vorname`       AS `vorname`,
         `s`.`GebDatum`      AS `gebdatum`,
         `s`.`SchulEintritt` AS `schuleintritt`,
         `k`.`Bezeichnung`   AS `bezeichnung`
  from (`datenmanagement`.`schueler` `s` join `datenmanagement`.`klasse` `k` on ((`s`.`KNr` = `k`.`KNr`)));

