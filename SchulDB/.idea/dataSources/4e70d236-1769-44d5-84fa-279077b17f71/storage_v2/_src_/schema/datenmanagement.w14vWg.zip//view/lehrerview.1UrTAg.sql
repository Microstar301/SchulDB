create definer = root@localhost view lehrerview as
select `datenmanagement`.`lehrer`.`PNr`           AS `PNr`,
       `datenmanagement`.`lehrer`.`Titel`         AS `Titel`,
       `datenmanagement`.`lehrer`.`Nachname`      AS `Nachname`,
       `datenmanagement`.`lehrer`.`Vorname`       AS `Vorname`,
       `datenmanagement`.`lehrer`.`Gebdatum`      AS `Gebdatum`,
       `datenmanagement`.`lehrer`.`SchulEintritt` AS `SchulEintritt`,
       `datenmanagement`.`lehrer`.`Stufe`         AS `Stufe`
from `datenmanagement`.`lehrer`;

