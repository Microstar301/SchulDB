create view aussicht as
  select `k`.`KursNr` AS `KursNr`, `k`.`Kursname` AS `Kursname`, `d`.`DozName` AS `DozName`
  from `muell`.`kurs` `k`
         join `muell`.`dozent` `d`
  where (`k`.`DozNr` = `d`.`DozNr`);

